Original CUBE, unchanged. Creator reports Photoshop use; other listed apps support CUBE import but this LUT has not been application-tested here. Colour ramp shows response to neutral input, not a photo preview.
Source: https://github.com/stripedpurple/color-grading-luts
Creator: Striped Purple; copyright notices preserved.
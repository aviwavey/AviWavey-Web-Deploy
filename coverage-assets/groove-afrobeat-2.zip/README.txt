Afrobeat — original MIDI rhythm study 2
A compact genre-inspired starting pattern for arranging. Use your own instruments and develop it into a full track; it is not a live performance or a complete genre reference.
Import the MIDI into your DAW and choose an instrument. The browser audition is a basic synthesiser, not a recorded performance.
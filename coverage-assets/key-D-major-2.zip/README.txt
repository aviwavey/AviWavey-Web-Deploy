D major — progression 2
Four-bar diatonic chord progression with bass and chord voicings.
Import the MIDI into your DAW and choose an instrument. The browser audition is a basic synthesiser, not a recorded performance.
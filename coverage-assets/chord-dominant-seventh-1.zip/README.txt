C dominant seventh — voicing study
Arpeggiated chord voicing study; chord quality is distinct from a song key.
Import the MIDI into your DAW and choose an instrument. The browser audition is a basic synthesiser, not a recorded performance.
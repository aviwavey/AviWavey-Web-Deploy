Requires DSK Overture VST, as stated by creator.
File verified as FLP; not opened in FL Studio here. Third-party plugins are not included.
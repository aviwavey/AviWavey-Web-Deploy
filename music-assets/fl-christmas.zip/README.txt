FL Studio stock plugins plus LABS Electric Piano, as stated by creator.
File verified as FLP; not opened in FL Studio here. Third-party plugins are not included.
Creator does not document complete plugin/sample dependencies; check in FL Studio before use.
File verified as FLP; not opened in FL Studio here. Third-party plugins are not included.